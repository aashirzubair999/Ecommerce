﻿using ClassLibraryDAL;
using ClassLibraryENT;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

namespace EcommerceAPI.Controllers
{
    [Route("api/store/")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        // GET: api/<CategoryController>
        [HttpGet]
        [Route("getorders")]
        public async Task<IActionResult> GetOrders()
        {
            List<ENTOrders> eNTCarts = await DALCRUD.GetEntitiesFromReadDataAsync<ENTOrders>("SP_GetOrders");

            return Ok(eNTCarts);
        }




        // POST api/<CategoryController>
        [HttpPost]
        [Route("addorder")]
        public async Task PostOrders(ENTOrders eNTOrders)
        {
            SqlParameter[] sp =
            {
                new SqlParameter("@FK_UserID", eNTOrders.FK_UserID),
                new SqlParameter("@FK_ProductID", eNTOrders.FK_ProductID),
                new SqlParameter("@OrderDate", eNTOrders.OrderDate)
            };

            await DALCRUD.SaveData("SP_SetOrder", sp);

        }



        // DELETE api/<CategoryController>/5
        [HttpDelete("deleteorder/{id}")]
        public async void DeleteOrder(int id)
        {
            SqlParameter[] sp =
      {
              new SqlParameter("@OrderID", id),
         };
            await DALCRUD.DeleteInfo("SP_DeleteOrder", sp);

        }



    }
}
