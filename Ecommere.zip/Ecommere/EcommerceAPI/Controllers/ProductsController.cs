﻿using ClassLibraryDAL;
using ClassLibraryENT;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EcommerceAPI.Controllers
{
    [Route("api/store/")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        // GET: api/<CategoryController>




        [HttpGet]
        [Route("getproducts")]
        public async Task<IActionResult> GetProducts()
        {
            List<ENTAddItemsInCategory> listentproducts = await DALCRUD.GetEntitiesFromReadDataAsync<ENTAddItemsInCategory>("SP_GetProducts");


            return Ok(listentproducts);
        }



        [HttpGet]
        [Route("getrandomproducts")]
        public async Task<IActionResult> GetRandomProducts()
        {
        
            List<ENTAddItemsInCategory> listentproducts = await DALCRUD.GetEntitiesFromReadDataAsync<ENTAddItemsInCategory>("SP_GetRandomProducts");


            return Ok(listentproducts);
        }


        [HttpGet]
        [Route("getproductsonsearch/{name}")]
        public async Task<IActionResult> GetProductsOnSearch(string name)
        {
            SqlParameter[] sp =
            {
                new SqlParameter("@ProductName", name)
            };
            List<ENTAddItemsInCategory> listentproducts = await DALCRUD.GetEntitiesFromReadDataAsync<ENTAddItemsInCategory>("SP_GetProductsOnSearch", sp);
            return Ok(listentproducts);
        }

        [HttpGet]
        [Route("getproductsbycategoryid/{id}")]
        public async Task<IActionResult> GetProductsByCategoryId(int id)
        {
            SqlParameter[] sp =
            {
                new SqlParameter("@FK_CategoryID", id)
            };
            List<ENTAddItemsInCategory> listentproducts = await DALCRUD.GetEntitiesFromReadDataAsync<ENTAddItemsInCategory>("SP_GetProductsByCategoryId", sp);
            return Ok(listentproducts);
        }



        [HttpGet]
        [Route("getproductsbyproductid/{id}")]
        public async Task<IActionResult> GetProductsByProductId(int id)
        {
            SqlParameter[] sp =
            {
                new SqlParameter("@ProductID", id)
            };
            List<ENTAddItemsInCategory> listentproducts = await DALCRUD.GetEntitiesFromReadDataAsync<ENTAddItemsInCategory>("SP_GetProductsByProductId", sp);
            return Ok(listentproducts);
        }


        // POST api/<CategoryController>
        [HttpPost]
        [Route("addproduct")]

        public async Task PostProducts(ENTAddItemsInCategory eNTAddItemsInCategory)
        {
            SqlParameter[] sp =
        {
            new SqlParameter("@ProductName",eNTAddItemsInCategory.ProductName),
            new SqlParameter("@ProductImageUrl",eNTAddItemsInCategory.ProductImageUrl),
            new SqlParameter("@ProductDescription",eNTAddItemsInCategory.ProductDescription ),
            new SqlParameter("@ProductPrice", eNTAddItemsInCategory.ProductPrice),
            new SqlParameter("@StockQuantity",eNTAddItemsInCategory.StockQuantity ),
            new SqlParameter("@FK_CategoryID", eNTAddItemsInCategory.FK_CategoryID)
        };

            await DALCRUD.SaveData("SP_SetProduct", sp);
        }

        // PUT api/<CategoryController>/5
        [HttpPut("updateproductsbyid")]
        public async void PutProducts(ENTAddItemsInCategory eNT)
        {
            SqlParameter[] sp =
       {
            new SqlParameter("@ProductID",eNT.ProductID),
            new SqlParameter("@ProductName",eNT.ProductName),
            new SqlParameter("@ProductImageUrl",eNT.ProductImageUrl),
            new SqlParameter("@ProductDescription",eNT.ProductDescription ),
            new SqlParameter("@ProductPrice", eNT.ProductPrice),
            new SqlParameter("@StockQuantity",eNT.StockQuantity ),
        };

            await DALCRUD.SaveData("SP_UpdateProduct", sp);

        }

        // DELETE api/<CategoryController>/5
        [HttpDelete("deleteproductsbyid/{id}")]
        public async void DeleteProductsById(int id)
        {
            SqlParameter[] sp =
            {
                new SqlParameter("@ProductID", id)
            };
            await DALCRUD.DeleteInfo("SP_DeleteProduct", sp);

        }
    }
}
