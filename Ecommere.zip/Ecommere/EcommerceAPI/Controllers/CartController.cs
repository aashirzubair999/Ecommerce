﻿using ClassLibraryDAL;
using ClassLibraryENT;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EcommerceAPI.Controllers
{
    [Route("api/store/")]
    [ApiController]
    public class CartController : ControllerBase
    {
        // GET: api/<CategoryController>
        [HttpGet]
        [Route("getcartitems")]
        public async Task<IActionResult> GetCartItems()
        {
            //SqlParameter[] sp =
            //{
            //    new SqlParameter("@FK_CategoryID", id)
            //};
            List<ENTCart> eNTCarts = await DALCRUD.GetEntitiesFromReadDataAsync<ENTCart>("SP_GetCartItems");

            return Ok(eNTCarts);
        }

        // GET: api/<CategoryController>
        [HttpGet]
        [Route("getcartitemsbyid/{id}")]
        public async Task<IActionResult> GetCartItemsByid(int id)
        {
            SqlParameter[] sp =
            {
                new SqlParameter("@FK_UserId", id)
            };
            List<ENTCart> eNTCarts = await DALCRUD.GetEntitiesFromReadDataAsync<ENTCart>("SP_GetCartItemsByUserId", sp);

            return Ok(eNTCarts);
        }



        // POST api/<CategoryController>
        [HttpPost]
        [Route("addcartitems")]
        public async Task PostCartItems(ENTCart eNTcart)
        {
            SqlParameter[] sp =
       {
            new SqlParameter("@ProductName", eNTcart.ProductName),
            new SqlParameter("@ProductDescription", eNTcart.ProductDescription),
            new SqlParameter("@ProductImageUrl", eNTcart.ProductImageUrl),
            new SqlParameter("@ProductPrice", eNTcart.ProductPrice),
            new SqlParameter("@FK_ProductID", eNTcart.FK_ProductID),
            new SqlParameter("@FK_UserId", eNTcart.FK_UserID)
       };

            await DALCRUD.SaveData("SP_SetCartItems", sp);

        }



        // DELETE api/<CategoryController>/5
        [HttpDelete("deletecartitemsbyuserid/{id}")]
        public async void DeleteCartItemByUserId(int id)
        {
            SqlParameter[] sp =
        {
            new SqlParameter("@UserId", id),
        };
            await DALCRUD.DeleteInfo("SP_deleteItemsFromCartByUserId", sp);

        }

        // DELETE api/<CategoryController>/5
        [HttpDelete("deletecartitemsbycartid/{id}")]
        public async void DeleteCartItemByCartID(int id)
            {
            SqlParameter[] sp =
        {
            new SqlParameter("@CartId", id),
        };
            await DALCRUD.DeleteInfo("SP_deleteItemsFromCartByCartId", sp);

        }


    }
}
