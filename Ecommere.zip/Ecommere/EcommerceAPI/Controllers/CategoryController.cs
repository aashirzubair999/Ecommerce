﻿using ClassLibraryDAL;
using ClassLibraryENT;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace EcommerceAPI.Controllers
{
    [Route("api/store/")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
       
        [HttpGet]
        [Route("getcategorybyid/{id}")]
        public async Task<IActionResult> GetCategoryById(int id)
        {
            SqlParameter[] sp =
            {
                new SqlParameter("@CategroyId", id)
            };

            List<ENTCategories> eNTAddItemsInCategory1 = await DALCRUD.GetEntitiesFromReadDataAsync<ENTCategories>("SP_GetCategoriesByCategoryId", sp);
            return Ok(eNTAddItemsInCategory1);
        }


        [HttpGet]
        [Route("gethomecategory")]
        public async Task<IActionResult> GethomeCategory()
        {
            List<ENTCategories> listentCategories = await DALCRUD.GetEntitiesFromReadDataAsync<ENTCategories>("SP_GetCategories");

            return Ok(listentCategories);
        }


        // POST api/<CategoryController>
        [HttpPost]
        [Route("addcategories")]
        public async Task<IActionResult> PostCategory(ENTCategories eNTCategories)
        {
            try
            {
                SqlParameter[] sp =
                {
                new SqlParameter("@CategoryName", eNTCategories.CategoryName),
                new SqlParameter("@CategoryImageURL", eNTCategories.CategoryImageURL),
                new SqlParameter("@CategoryDescription", eNTCategories.CategoryDescription),
                new SqlParameter("@ResultMessage", SqlDbType.NVarChar, 255) { Direction = ParameterDirection.Output }
            };

                    string resultMessage = null;

                // Call SaveData and handle the result
                await DALCRUD.SaveData("SP_SetCategory", sp, (output) =>
                {
                    resultMessage = output;
                });

                // Return appropriate response based on resultMessage
                if (!string.IsNullOrEmpty(resultMessage))
                {
                    if (resultMessage == "Category already exists.")
                    {
                        return Conflict(new { Message = resultMessage }); // HTTP 409 Conflict
                    }
                    else
                    {
                        return Ok(new { Message = resultMessage }); // HTTP 200 OK
                    }
                }

                return StatusCode(500, new { Message = "An unknown error occurred." }); // HTTP 500 Internal Server Error
            }
            catch (Exception ex)
            {
                // Log exception and return HTTP 500
                Console.WriteLine($"Exception Occurred: {ex.Message}");
                return StatusCode(500, new { Message = "An error occurred while processing the request." });
            }
        }

        // PUT api/<CategoryController>/5
        [HttpPut]
        [Route("updatecategoriesbyid")]
        public async Task UpdateCategories(ENTCategories eNTCategories)
        {
            SqlParameter[] sp =
            {
            new SqlParameter("@CategoryID", eNTCategories.CategoryID),
            new SqlParameter("@CategoryImageURL", eNTCategories.CategoryImageURL),
            new SqlParameter("@CategoryName", eNTCategories.CategoryName),
            new SqlParameter("@CategoryDescription", eNTCategories.CategoryDescription)
            };
            await DALCRUD.SaveData("SP_UpdateCategory", sp);

        }



        // DELETE api/<CategoryController>/5
        [HttpDelete("deletecategoriesbyid/{id}")]
        public async void DeleteCategoryById(int id)
        {
            SqlParameter[] sp =
            {
                new SqlParameter("@CategoryID", id)
            };
            await DALCRUD.DeleteInfo("SP_DeleteCategory", sp);

        }
    }
}
