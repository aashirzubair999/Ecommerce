﻿internal class inject
{
}