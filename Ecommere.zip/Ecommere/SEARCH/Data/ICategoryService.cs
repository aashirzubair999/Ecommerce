﻿using ClassLibraryENT;

namespace SEARCH.Data
{
    public interface ICategoryService
    {
        Task<List<ENTCategories>> GetHomeCategory();
        Task<List<ENTCategories>> GetHomeCategoryById(int id);
        Task UpdateCategory(ENTCategories eNTCategories);
        Task AddCategory(ENTCategories eNTCategories);
        Task DeleteCategory(int id);
    }
}
