﻿using ClassLibraryENT;

namespace SEARCH.Data
{
    public interface IProductService
    {
        Task<List<ENTAddItemsInCategory>> GetProducts();
        Task<List<ENTAddItemsInCategory>> GetRandomProducts();
        Task<List<ENTAddItemsInCategory>> GetProductsOnSearch(string name);

        Task<List<ENTAddItemsInCategory>> GetProductsByCategoryId(int id);
        Task<List<ENTAddItemsInCategory>> GetProductsByProductId(int id);
        Task UpdateProduct(ENTAddItemsInCategory eNTAddItemsInCategory);
        Task AddProducts(ENTAddItemsInCategory eNTAddItemsInCategory);
        Task DeleteProducts(int id);
    }
}
