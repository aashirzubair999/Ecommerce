﻿using ClassLibraryENT;

namespace SEARCH.Data
{
    public class OrderService : IOrderService
    {
        private readonly HttpClient _httpClient;

        public OrderService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        public async Task AddOrders(ENTOrders eNTOrders)
        {
            await _httpClient.PostAsJsonAsync("addorder", eNTOrders);
        }

        public async Task DeleteOrders(int id)
        {
            await _httpClient.DeleteAsync($"deleteorder/{id}");
        }

        public async Task<List<ENTOrders>> GetOrders()
        {
            return await _httpClient.GetFromJsonAsync<List<ENTOrders>>("getorders");

        }
    }
}
