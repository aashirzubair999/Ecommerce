﻿using ClassLibraryENT;

namespace SEARCH.Data
{
    public interface ICartService
    {
        Task<List<ENTCart>> GetCartItems();
        Task<List<ENTCart>> GetCartItemsById(int id);

        Task AddCartItems(ENTCart eNTCart);

        Task DeleteCartItemsByUserID(int id);
        Task DeleteCartItemsByCartID(int id);

    }
}
