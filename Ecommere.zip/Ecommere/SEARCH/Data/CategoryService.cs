﻿using ClassLibraryENT;
using System.Net.Http;

namespace SEARCH.Data
{
    public class CategoryService : ICategoryService
    {
        private readonly HttpClient httpClient;

        public CategoryService(HttpClient _httpClient)
        {
            httpClient = _httpClient;
        }

        public async Task AddCategory(ENTCategories eNTCategories)
        {
            await httpClient.PostAsJsonAsync("addcategories", eNTCategories);
        }

        public async Task DeleteCategory(int id)
        {
            await httpClient.DeleteAsync($"deletecategoriesbyid/{id}");
        }

        public async Task<List<ENTCategories>> GetHomeCategory()
        {
            return await httpClient.GetFromJsonAsync<List<ENTCategories>>("gethomecategory");
        }

        public async Task<List<ENTCategories>> GetHomeCategoryById(int id)
        {
            return await httpClient.GetFromJsonAsync<List<ENTCategories>>($"getcategorybyid/{id}");
        }

        public async Task UpdateCategory(ENTCategories eNTCategories)
        {
            Console.WriteLine(eNTCategories);
            await httpClient.PutAsJsonAsync("updatecategoriesbyid", eNTCategories);
        }

    }
}
