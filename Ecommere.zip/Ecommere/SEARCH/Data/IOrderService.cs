﻿using ClassLibraryENT;

namespace SEARCH.Data
{
    public interface IOrderService
    {
        Task<List<ENTOrders>> GetOrders();
      
        Task AddOrders(ENTOrders eNTOrders);

        Task DeleteOrders(int id);

    }
}
