﻿using ClassLibraryENT;

namespace SEARCH.Data
{
    public class CartService : ICartService
    {

        private readonly HttpClient _httpClient;
        public CartService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }



        public async Task AddCartItems(ENTCart eNTCart)
        {
            await _httpClient.PostAsJsonAsync("addcartitems", eNTCart);
        }

        public async Task DeleteCartItemsByUserID(int id)
        {
             await _httpClient.DeleteAsync($"deletecartitemsbyuserid/{id}");
        }

        public async Task DeleteCartItemsByCartID(int id)
        {
            await _httpClient.DeleteAsync($"deletecartitemsbycartid/{id}");
        }


        public async Task<List<ENTCart>> GetCartItems()
        {
            return await _httpClient.GetFromJsonAsync<List<ENTCart>>("getcartitems");

        }

        public async Task<List<ENTCart>> GetCartItemsById(int id)
        {
            return await _httpClient.GetFromJsonAsync<List<ENTCart>>($"getcartitemsbyid/{id}");
        }

 
    }
}
