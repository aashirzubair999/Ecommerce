﻿using ClassLibraryENT;

namespace SEARCH.Data
{
    public class ProductService : IProductService
    {
        private readonly HttpClient _httpClient;

        public ProductService(HttpClient httpClient) {
            _httpClient = httpClient;
        }

        public async Task AddProducts(ENTAddItemsInCategory eNTAddItemsInCategory)
        {
            await _httpClient.PostAsJsonAsync("addproduct", eNTAddItemsInCategory);
        }

        public async Task DeleteProducts(int id)
        {
            await _httpClient.DeleteAsync($"deleteproductsbyid/{id}");
        }

        public async Task<List<ENTAddItemsInCategory>> GetProducts()
        {
            return await _httpClient.GetFromJsonAsync<List<ENTAddItemsInCategory>>("getproducts");
        }
        public async Task<List<ENTAddItemsInCategory>> GetProductsOnSearch(string name)
        {
            return await _httpClient.GetFromJsonAsync<List<ENTAddItemsInCategory>>($"getproductsonsearch/{name}");
        }

        public async Task<List<ENTAddItemsInCategory>> GetRandomProducts()
        {
            return await _httpClient.GetFromJsonAsync<List<ENTAddItemsInCategory>>("getrandomproducts");

        }
        public async Task<List<ENTAddItemsInCategory>> GetProductsByCategoryId(int id)
        {
            return await _httpClient.GetFromJsonAsync<List<ENTAddItemsInCategory>>($"getproductsbycategoryid/{id}");
        }
        public async Task<List<ENTAddItemsInCategory>> GetProductsByProductId(int id)
        {
            return await _httpClient.GetFromJsonAsync<List<ENTAddItemsInCategory>>($"getproductsbyproductid/{id}");
        }

   

        public async Task UpdateProduct(ENTAddItemsInCategory eNTAddItemsInCategory)
        {
             await _httpClient.PutAsJsonAsync("updateproductsbyid", eNTAddItemsInCategory);

        }


    }
}
