﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryENT
{

    public class ENTOrderDetails
    {
        public int OrderDetailId { get; set; }
        public string? FirstName { get; set; } // Required, hence no nullable type
        public string? LastName { get; set; } // Required, hence no nullable type
        public string? phoneNumber { get; set; } // Nullable in case the phone number is optional
        public string? Email { get; set; } // Nullable for optional email
        public string? Address { get; set; } // Required
        public int ZipCode { get; set; } // Required, assuming valid zip codes are always present
        public int FK_UserID { get; set; } // Foreign Key for User
        public int FK_ProductID { get; set; } // Foreign Key for Product


    }
}

