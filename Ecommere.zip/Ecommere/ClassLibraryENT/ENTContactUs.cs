﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryENT
{
	public class ENTContactUs
	{
		public int ContactId { get; set; }
		public string? Fname { get; set; }
		public string? Lname { get; set; }
		public string? Email { get; set; }
		public string? Message { get; set; }

	}
}
