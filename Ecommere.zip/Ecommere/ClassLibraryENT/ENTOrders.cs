﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryENT
{
    public class ENTOrders
    {
        public int OrderID { get; set; }
        public int FK_UserID { get; set; }
        public int FK_ProductID { get; set; }
        public string? OrderDate { get; set; }
    }
}
