﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryENT
{
    public class ENTAddItemsInCategory
    {
        public int ProductID { get; set; }
        [Required(ErrorMessage = "Product Name is required")]
        public string? ProductName { get; set; }
        [Required(ErrorMessage = "Product image is required")]
        public string? ProductImageUrl { get; set; }

        [Required(ErrorMessage = "Product Description is required")]
        public string? ProductDescription { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Product Price cannot be negative")]
        public decimal ProductPrice { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Stock Quantity cannot be negative")]
        public int StockQuantity { get; set; }
        public int FK_CategoryID { get; set; }
    }
}
