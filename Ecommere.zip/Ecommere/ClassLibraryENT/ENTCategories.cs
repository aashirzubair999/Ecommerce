﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ClassLibraryENT
{
    public class ENTCategories
    {
        
        public int CategoryID { get; set; }
        [Required(ErrorMessage = "Category Image is required")]

        public string? CategoryImageURL { get; set; }

        [Required(ErrorMessage = "Category Name is required")]
        public string? CategoryName { get; set; }

        [Required(ErrorMessage = "Category Description is required")]
        public string? CategoryDescription { get; set; }


    }
}

