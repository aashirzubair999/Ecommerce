﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ClassLibraryDAL
{
    public class DALCRUD
    {

        public static async Task SaveData(string ProcedureName, SqlParameter[] sqlParameters)
        {
            try
            {
                using (SqlConnection con = DBHelper.GetConnection())
                {
                    await con.OpenAsync();
                    using (SqlCommand cmd = new SqlCommand(ProcedureName, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddRange(sqlParameters);
                        await cmd.ExecuteNonQueryAsync();
                        await con.CloseAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception Occurred: {ex.Message}");
            }
        }

        public static async Task SaveData(string storedProcedureName, SqlParameter[] parameters, Action<string> processOutput = null)
        {
            try
            {
                using (SqlConnection con = DBHelper.GetConnection())
                {
                    SqlCommand cmd = new SqlCommand(storedProcedureName, con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };

                    // Add parameters to the command
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }

                    await con.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();

                    // Retrieve the output parameter value
                    var resultMessage = cmd.Parameters["@ResultMessage"].Value.ToString();
                    Console.WriteLine($"Result Message: {resultMessage}");

                    // Process the output using the callback
                    processOutput?.Invoke(resultMessage);

                    con.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception Occurred: {ex.Message}");
            }
        }

        public static async Task<DataTable> ReadSpecificDataTable(string ProcedureName, SqlParameter[] sqlParameters)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection conn = DBHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(ProcedureName, conn))
                    {
                        await conn.OpenAsync();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddRange(sqlParameters);
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        sda.Fill(dt);
                        SqlDataReader rdr = await cmd.ExecuteReaderAsync();
                        await conn.CloseAsync();

                        if (dt.Rows.Count > 0)
                        {

                            return dt;

                        }
                        else { return new DataTable(); }
                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception Occurred: {ex.Message}");
            }
            return new DataTable();

        }

        public static async Task<string> ReadDataAsync(string procedureName)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection conn = DBHelper.GetConnection())
                {
                    using (SqlCommand cmd = new SqlCommand(procedureName, conn))
                    {
                        await conn.OpenAsync();
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);
                        sda.Fill(dt);
                        await conn.CloseAsync();

                        if (dt.Rows.Count > 0)
                        {
                            return DalCustomLogics.DataTableToJSONWithJSONNet(dt);
                        }
                        else
                        {
                            return string.Empty;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception Occurred: {ex.Message}");
                return string.Empty;
            }
        }
        public static async Task<string> ReadDataAsync(string procedureName, SqlParameter[] sp)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection conn = DBHelper.GetConnection())
                {

                    SqlCommand cmd = new SqlCommand(procedureName, conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(sp);
                    await conn.OpenAsync();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                    await conn.CloseAsync();

                    if (dt.Rows.Count > 0)
                    {
                        return DalCustomLogics.DataTableToJSONWithJSONNet(dt);
                    }
                    else
                    {
                        return string.Empty;
                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception Occurred: {ex.Message}");
                return string.Empty;
            }
        }

        public static async Task<List<T>> GetEntitiesFromReadDataAsync<T>(string procedureName)
        {
            string jsonData = await ReadDataAsync(procedureName);

            if (!string.IsNullOrEmpty(jsonData))
            {
                return JsonSerializer.Deserialize<List<T>>(jsonData);
            }

            return new List<T>();
        }
        public static async Task<List<T>> GetEntitiesFromReadDataAsync<T>(string procedureName, SqlParameter[] sp)
        {
            string jsonData = await ReadDataAsync(procedureName, sp);

            if (!string.IsNullOrEmpty(jsonData))
            {
                return JsonSerializer.Deserialize<List<T>>(jsonData);
            }

            return new List<T>();
        }

        public static async Task DeleteInfo(string procedureName, SqlParameter[] parameters)
        {
            using (SqlConnection con = DBHelper.GetConnection())
            {
                await con.OpenAsync();
                using (SqlCommand cmd = new SqlCommand(procedureName, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(parameters);
                    await cmd.ExecuteNonQueryAsync();
                }
                await con.CloseAsync();
            }
        }


        public static async Task UpdateInfo<T>(string procedureName, SqlParameter[] sqlParameters)
        {
            try
            {
                using (SqlConnection con = DBHelper.GetConnection())
                {
                    await con.OpenAsync();
                    using (SqlCommand cmd = new SqlCommand(procedureName, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddRange(sqlParameters);
                        await cmd.ExecuteNonQueryAsync();
                    }
                    await con.CloseAsync();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception Occurred: {ex.Message}");
            }
        }

        public static async Task UpdateInfo(string procedureName, SqlParameter[] sqlParameters)
        {
            try
            {
                using (SqlConnection con = DBHelper.GetConnection())
                {
                    await con.OpenAsync();
                    using (SqlCommand cmd = new SqlCommand(procedureName, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddRange(sqlParameters);
                        await cmd.ExecuteNonQueryAsync();
                    }
                    await con.CloseAsync();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception Occurred: {ex.Message}");
            }
        }





    }
}
